﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace Presentation.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly HttpClient _httpClient;

        public UsuarioController(HttpClient _httpClient) 
        {
            this._httpClient = _httpClient;
        }

        public async Task<IActionResult> GetAll()
        {
            try
            {
                var response = await _httpClient.GetAsync("Usuario");
                response.EnsureSuccessStatusCode();

                var data = await response.Content.ReadAsStringAsync();
                Model.DataResult<Model.Usuario> dataResult = JsonSerializer.Deserialize<Model.DataResult<Model.Usuario>>(data);

                if (dataResult.Result)
                {
                    return View(dataResult.Values);
                }
                else
                {
                    ViewBag.Message = $"Ocurrio un error: {dataResult.Message}";
                    return PartialView("Modal");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Ocurrio un Error: {ex.Message}";
                return PartialView("Modal"); ;
            }
        }
    }
}
